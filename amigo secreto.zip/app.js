// Array para almacenar los nombres
let amigos = [];

// Función para agregar nombres a la lista
function agregarAmigo() {
    const input = document.getElementById("amigo");
    const lista = document.getElementById("listaAmigos");
    const nombre = input.value.trim(); // Limpiar espacios

    // Validaciones
    if (nombre === "") {
        alert("Por favor, ingresa un nombre válido.");
        return;
    }
    if (amigos.includes(nombre)) {
        alert("Este nombre ya ha sido agregado.");
        return;
    }

    // Agregar nombre al array
    amigos.push(nombre);

    // Limpiar y actualizar la lista
    actualizarLista();

    // Limpiar el campo de entrada
    input.value = "";
}

// Función para actualizar la lista de amigos en el HTML
function actualizarLista() {
    let lista = document.querySelector("#listaAmigos"); // Obtener la lista
    lista.innerHTML = ""; // Limpiar la lista antes de agregar nuevos elementos

    for (let i = 0; i < amigos.length; i++) {
        let li = document.createElement("li"); // Crear un elemento <li>
        li.textContent = amigos[i]; // Asignar el nombre del amigo
        lista.appendChild(li); // Agregar el <li> a la lista
    }
}

// Función para sortear el amigo secreto
function sortearAmigo() {
    if (amigos.length < 2) {
        alert("Debe haber al menos dos nombres en la lista para sortear.");
        return;
    }

    // Crear un mapeo de parejas sin que nadie se asigne a sí mismo
    let disponibles = [...amigos];
    let resultado = [];

    for (let i = 0; i < amigos.length; i++) {
        let nombre = amigos[i];
        let opciones = disponibles.filter((amigo) => amigo !== nombre);

        if (opciones.length === 0) {
            // Si no quedan opciones, se vuelve a mezclar
            return sortearAmigo();
        }

        let indiceAleatorio = Math.floor(Math.random() * opciones.length);
        let amigoSecreto = opciones[indiceAleatorio];

        // Asignar y remover de los disponibles
        resultado.push(`${nombre} → ${amigoSecreto}`);
        disponibles.splice(disponibles.indexOf(amigoSecreto), 1);
    }

    // Mostrar el resultado
    const resultadoLista = document.getElementById("resultado");
    resultadoLista.innerHTML = ""; // Limpiar la lista antes de actualizarla

    resultado.forEach((asignacion) => {
        const li = document.createElement("li");
        li.textContent = asignacion;
        resultadoLista.appendChild(li);
    });
}
